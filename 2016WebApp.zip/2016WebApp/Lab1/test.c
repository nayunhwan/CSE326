#include <stdio.h>

int main()
{
	int i = 0;
	scanf("%d", &i);
	if(i == 1)
	{
		printf("julian8748@gmail.com\n");
	}
	if(i == 2)
	{
		printf("01087483782\n");
	}
	

	return 0;
}
