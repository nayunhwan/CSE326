<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <p>
    <?php
      $hello = "hello";
      print $hello;
     ?>
    </p>
  </body>
</html>
